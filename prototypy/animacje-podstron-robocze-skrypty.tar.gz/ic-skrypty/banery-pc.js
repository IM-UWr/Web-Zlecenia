// Zbiera wygląd banerów podstron z grupy „Instytut i codzienność studiów” (390 px, telefon) z gotowej strony.
const { chromium } = require('playwright');
const OUT = '/tmp/claude-0/-home-claude/f8da5dc6-8de1-54ed-a382-aba453ec50fb/scratchpad/ic-zrzuty/';
const BASE = 'http://localhost:8715/Web-Core';
const STRONY = [
  ['wladze', '/instytut/wladze/'],
  ['pracownicy', '/pracownicy/'],
  ['struktura', '/instytut/struktura/'],
  ['zaklad', '/instytut/zaklady/teoria-prawdopodobienstwa/'],
  ['zaklad2', '/instytut/zaklady/teoria-mnogosci-i-topologia/'],
  ['zaklad3', '/instytut/zaklady/dydaktyka/'],
  ['kontakt', '/instytut/kontakt/'],
  ['infra', '/instytut/infrastruktura-informatyczna/'],
  ['infra-pod', '/instytut/infrastruktura-informatyczna/regulamin-sieci/'],
  ['plan', '/studia/plan-zajec/'],
  ['rok', '/studia/rok-akademicki/'],
  ['kal-zajec', '/studia/kalendarz-zajec/'],
  ['pierwszy', '/studia/pierwszy-rok/'],
  ['egzaminy', '/studia/egzaminy-i-dyplom/'],
  ['procedura', '/studia/procedura-dyplomowania/'],
  ['ww', '/warto-wiedziec/'],
  ['ww-wpis', '/warto-wiedziec/wyklad-terencea-tao/'],
  ['ww-wpis2', '/warto-wiedziec/artykul-w-annals-of-mathematics/'],
  ['ww-wpis3', '/warto-wiedziec/test-umowa-o-wspolpracy-z-uniwersytetem-test/'],
  ['deklaracja', '/deklaracja-dostepnosci/'],
  ['szukaj', '/szukaj/'],
  ['powiadomienia', '/powiadomienia/'],
];
(async () => {
  const b = await chromium.launch();
  const kontekst = await b.newContext({ viewport: { width: 1440, height: 900 }, deviceScaleFactor: 2, reducedMotion: 'reduce' });
  const p = await kontekst.newPage();
  const wynik = [];
  for (const [n, adres] of STRONY) {
    await p.goto(BASE + adres, { waitUntil: 'load' });
    await p.waitForTimeout(400);
    const info = await p.evaluate(() => {
      const ph = document.querySelector('.page-head');
      if (!ph) return { brak: true, url: location.pathname, h1: (document.querySelector('h1') || {}).textContent };
      const r = ph.getBoundingClientRect();
      const vis = (el) => el && getComputedStyle(el).display !== 'none' && el.getBoundingClientRect().height > 0;
      const q = (s) => ph.querySelector(s);
      const h1 = q('h1');
      const rg = document.createRange(); rg.selectNodeContents(h1);
      const rects = Array.from(rg.getClientRects());
      const linie = new Set(rects.map((x) => Math.round(x.top))).size;
      const rr = rg.getBoundingClientRect();
      const kids = Array.from(ph.querySelector('.wrap').children).filter(vis).map((el) => {
        const b = el.getBoundingClientRect();
        return { tag: el.tagName.toLowerCase(), cls: el.className && el.className.baseVal === undefined ? el.className : '', t: Math.round(b.top - r.top), h: Math.round(b.height), l: Math.round(b.left), w: Math.round(b.width), txt: (el.textContent || '').trim().slice(0, 80) };
      });
      const cs = getComputedStyle(h1);
      return {
        url: location.pathname, cls: ph.className, dzial: ph.dataset.dzial, H: Math.round(r.height), W: Math.round(r.width),
        tytul: h1.textContent.trim(), linie, koniecTytulu: Math.round(rr.right - r.left), fs: cs.fontSize,
        foto: !!q('.ph-foto'), kids,
      };
    });
    info.n = n;
    wynik.push(info);
    if (!info.brak) {
      const el = await p.$('.page-head');
      // zrzut z nagłówkiem (pasek menu leży na pasie)
      const box = await el.boundingBox();
      await p.screenshot({ path: OUT + 'pc-baner-' + n + '.png', clip: { x: 0, y: 0, width: 1440, height: Math.ceil(box.y + box.height + 24) } });
    } else {
      await p.screenshot({ path: OUT + 'pc-baner-' + n + '.png', clip: { x: 0, y: 0, width: 1440, height: 480 } });
    }
  }
  console.log(JSON.stringify(wynik, null, 1));
  await b.close();
})();
