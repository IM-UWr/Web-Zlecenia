const { chromium } = require('playwright');
const BASE = 'http://localhost:8715/Web-Core';
const S = ['/instytut/wladze/','/pracownicy/','/instytut/struktura/','/instytut/zaklady/teoria-prawdopodobienstwa/','/instytut/kontakt/','/instytut/infrastruktura-informatyczna/','/studia/plan-zajec/','/studia/rok-akademicki/','/studia/pierwszy-rok/','/studia/egzaminy-i-dyplom/','/studia/procedura-dyplomowania/','/warto-wiedziec/','/warto-wiedziec/wyklad-terencea-tao/','/deklaracja-dostepnosci/','/szukaj/'];
(async () => {
  const b = await chromium.launch(); const p = await b.newPage({ viewport: { width: 1440, height: 900 } });
  for (const s of S) {
    await p.goto(BASE + s);
    const r = await p.evaluate(() => { const ph = document.querySelector('.page-head'); const q = (x) => { const e = ph.querySelector(x); return e ? e.innerText.replace(/\n+/g, ' | ') : null; };
      return { w: q('.wstecz'), h: q('h1'), lead: q('.lead'), tags: q('.tags'), meta: q('.ww-meta'), liczby: q('.pt-liczby'), first: (() => { const n = ph.nextElementSibling; const f = n && n.querySelector('input, table, .kd-dzis, .pz-semestr, h2, .prose > *'); return f ? f.tagName + '.' + f.className + ' ' + (f.innerText || f.placeholder || '').slice(0, 60) : null; })() }; });
    console.log(s, JSON.stringify(r));
  }
  await b.close();
})();
