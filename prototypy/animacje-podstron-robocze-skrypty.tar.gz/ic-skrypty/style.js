const { chromium } = require('playwright');
const BASE = 'http://localhost:8715/Web-Core';
(async () => {
  const b = await chromium.launch();
  for (const sch of ['light', 'dark']) {
    const p = await b.newPage({ viewport: { width: 390, height: 844 }, colorScheme: sch });
    for (const adres of ['/instytut/zaklady/teoria-prawdopodobienstwa/', '/warto-wiedziec/wyklad-terencea-tao/', '/szukaj/']) {
      await p.goto(BASE + adres);
      const r = await p.evaluate(() => {
        const ph = document.querySelector('.page-head');
        const g = (el, props) => { if (!el) return null; const c = getComputedStyle(el); const o = {}; props.forEach((k) => o[k] = c.getPropertyValue(k)); return o; };
        const P = ['font-size', 'font-weight', 'line-height', 'color', 'background-color', 'letter-spacing', 'margin-top', 'margin-bottom', 'padding', 'border-radius', 'gap', 'display', 'opacity', 'border'];
        return {
          ph: g(ph, ['background-color', 'background-image', 'padding', 'min-height']),
          wrap: g(ph.querySelector('.wrap'), ['padding', 'gap', 'display', 'flex-direction', 'row-gap']),
          wstecz: g(ph.querySelector('.wstecz'), P), wa: g(ph.querySelector('.wstecz a'), P),
          h1: g(ph.querySelector('h1'), P),
          lead: g(ph.querySelector('.lead'), P),
          tags: g(ph.querySelector('.tags'), P), badge: g(ph.querySelector('.tags .badge'), P),
          meta: g(ph.querySelector('.ww-meta'), P), metab: g(ph.querySelector('.ww-meta .badge'), P), metaa: g(ph.querySelector('.ww-meta a'), [...P, 'text-decoration']),
          fotoAfter: (() => { const f = ph.querySelector('.ph-foto'); if (!f) return null; const c = getComputedStyle(f, '::after'); return { bg: c.backgroundImage, op: c.opacity }; })(),
          foto: g(ph.querySelector('.ph-foto'), ['opacity', 'filter', 'mix-blend-mode', 'background-color']),
          img: g(ph.querySelector('.ph-foto img'), ['opacity', 'filter', 'mix-blend-mode', 'object-position']),
          imgsrc: (ph.querySelector('.ph-foto img') || {}).src,
          phm: g(ph.querySelector('.ph-m'), ['opacity', 'top', 'right', 'width', 'height']),
          phmb: (() => { const m = ph.querySelector('.ph-m'); const c = getComputedStyle(m, '::before'); return { bg: c.backgroundColor, mask: c.maskImage ? c.maskImage.slice(0, 80) : c.webkitMaskImage && c.webkitMaskImage.slice(0, 80) }; })(),
          before: (() => { const c = getComputedStyle(ph, '::before'); return { bg: c.backgroundImage, h: c.height, content: c.content }; })(),
          next: (() => { const n = ph.nextElementSibling; return n ? n.className + ' ' + getComputedStyle(n).paddingTop : null; })(),
        };
      });
      console.log(sch, adres, JSON.stringify(r, null, 1));
    }
    await p.close();
  }
  await b.close();
})();
