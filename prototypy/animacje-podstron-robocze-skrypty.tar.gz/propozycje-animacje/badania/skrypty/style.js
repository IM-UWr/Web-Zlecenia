const { chromium } = require('playwright');
const B = 'http://localhost:8714/Web-Core';
(async () => {
  const br = await chromium.launch();
  for (const szer of [390, 1440]) {
  const p = await br.newPage({ viewport: { width: szer, height: 800 } });
  for (const a of ['/nauka/granty/2025-2024-53-n-st1-02294/', '/nauka/publikacje/2024/', '/nauka/granty/']) {
    await p.goto(B + a, { waitUntil: 'networkidle' });
    const r = await p.evaluate(() => {
      const ph = document.querySelector('.page-head');
      const pick = (el) => { if (!el) return null; const c = getComputedStyle(el); const r = el.getBoundingClientRect(); return { tag: el.tagName, cls: el.className, txt: el.textContent.trim().slice(0, 60), r: [r.left, r.top, r.width, r.height].map(Math.round), fs: c.fontSize, fw: c.fontWeight, lh: c.lineHeight, col: c.color, bg: c.backgroundColor, bd: c.border, br: c.borderRadius, pad: c.padding, gap: c.gap, mt: c.marginTop, mb: c.marginBottom, ls: c.letterSpacing, h: c.height, minh: c.minHeight, ff: c.fontFamily.slice(0, 30) }; };
      const out = [];
      out.push(pick(ph));
      out.push(pick(ph.querySelector('.wrap')));
      ph.querySelectorAll('.wstecz, .wstecz a, .wstecz svg, h1, .lead, .tags, .badge, .pr-akcje, .pr-pdf, .pr-pdf svg, .pt-liczby, .pt-liczby li, .pt-liczby .n, .badge::before, .gr-stan').forEach(e => out.push(pick(e)));
      const st = document.querySelector('.gr-trwa'); if (st) { const c = getComputedStyle(st, '::before'); out.push({ before: c.content, w: c.width, h: c.height, bg: c.backgroundColor, br: c.borderRadius, mr: c.marginRight }); }
      return out;
    });
    console.log('=====', szer, a); r.forEach(x => console.log(JSON.stringify(x)));
  }
  }
  await br.close();
})();
