const { chromium } = require('playwright');
const B = 'http://localhost:8714/Web-Core';
(async () => {
  const br = await chromium.launch();
  const p = await br.newPage({ viewport: { width: 390, height: 800 } });
  for (const a of ['/nauka/granty/', '/nauka/publikacje/', '/nauka/sukcesy/', '/nauka/granty/2025-2024-53-n-st1-02294/', '/nauka/granty/2018-2017-25-b-st1-000599/', '/nauka/granty/2009-ep-g068720-1/', '/nauka/granty/2014-2014-12-s-st1-00491/']) {
    await p.goto(B + a, { waitUntil: 'networkidle' });
    const r = await p.evaluate(() => {
      const ph = document.querySelector('.page-head');
      const b = [...ph.querySelectorAll('.badge')].map(e => ({ t: e.textContent.trim(), cls: e.className, sh: getComputedStyle(e).boxShadow, bg: getComputedStyle(e).backgroundColor, col: getComputedStyle(e).color }));
      return { h1: ph.querySelector('h1').textContent, lead: ph.querySelector('.lead')?.textContent, liczby: [...ph.querySelectorAll('.pt-liczby li')].map(l => l.textContent.trim()), b, wst: ph.querySelector('.wstecz').textContent.trim() };
    });
    console.log(a, JSON.stringify(r));
  }
  const lata = [];
  for (let y = 2003; y <= 2025; y++) {
    await p.goto(B + '/nauka/publikacje/' + y + '/', { waitUntil: 'domcontentloaded' });
    lata.push([y, await p.evaluate(() => document.querySelector('.page-head .lead')?.textContent)]);
  }
  console.log(JSON.stringify(lata));
  await br.close();
})();
