const { chromium } = require('playwright');
const OUT = '/tmp/claude-0/-home-claude/f8da5dc6-8de1-54ed-a382-aba453ec50fb/scratchpad/propozycje-animacje/badania/zrzuty-strony/';
const B = 'http://localhost:8714/Web-Core';
const strony = {
  nauka: '/nauka/',
  granty: '/nauka/granty/',
  grant56: '/nauka/granty/2025-2024-53-n-st1-02294/',
  grant17: '/nauka/granty/2014-2014-12-s-st1-00491/',
  grant106: '/nauka/granty/2009-ep-g068720-1/',
  grant104: '/nauka/granty/2018-2017-25-b-st1-000599/',
  publikacje: '/nauka/publikacje/',
  rok2024: '/nauka/publikacje/2024/',
  sukcesy: '/nauka/sukcesy/',
};
(async () => {
  const br = await chromium.launch();
  for (const [szer, dsf] of [[390, 2], [1440, 1]]) {
    const ctx = await br.newContext({ viewport: { width: szer, height: 800 }, deviceScaleFactor: dsf });
    const p = await ctx.newPage();
    for (const [n, a] of Object.entries(strony)) {
      await p.goto(B + a, { waitUntil: 'networkidle' });
      await p.waitForTimeout(400);
      const info = await p.evaluate(() => {
        const ph = document.querySelector('.page-head');
        if (!ph) return null;
        const R = (el) => { if (!el) return null; const r = el.getBoundingClientRect(); return [Math.round(r.left), Math.round(r.top), Math.round(r.right), Math.round(r.bottom)]; };
        const h1 = ph.querySelector('h1'); const rg = document.createRange(); rg.selectNodeContents(h1);
        const rr = rg.getClientRects();
        const lines = [...rr].map(r => [Math.round(r.left), Math.round(r.top), Math.round(r.right), Math.round(r.bottom)]);
        const cs = getComputedStyle(h1);
        const kids = [...ph.querySelector('.wrap').children].map(c => ({ tag: c.tagName, cls: c.className, vis: getComputedStyle(c).display, r: R(c), txt: (c.textContent || '').trim().slice(0, 80) }));
        return { cls: ph.className, ph: R(ph), h1: R(h1), lines, fs: cs.fontSize, lh: cs.lineHeight, ls: cs.letterSpacing, fw: cs.fontWeight, kids, hdr: R(document.querySelector('.hdr')) };
      });
      console.log(szer, n, JSON.stringify(info));
      const ph = await p.$('.page-head');
      if (ph) { const bb = await ph.boundingBox(); await p.screenshot({ path: OUT + `${n}-${szer}.png`, clip: { x: 0, y: 0, width: szer, height: Math.ceil(bb.y + bb.height + (szer < 500 ? 140 : 40)) } }); }
    }
    await ctx.close();
  }
  await br.close();
})();
